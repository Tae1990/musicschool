<footer>copyright</footer><!--footer-->
</div><!--flex-container-->
</div><!--containner-->
</body>
</html>