<?php
        include "../modules/session.php";
		include "../modules/database.php";
		include "../modules/sanitize.php";
		include "teacherHeader.php";
		include "../modules/loginSession.php";
		include "instrumentBody.php";
		include "footer.php";
?>