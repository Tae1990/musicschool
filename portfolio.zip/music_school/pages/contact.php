<?php
        include "../modules/session.php";
		include "../modules/database.php";
		include "../modules/sanitize.php";
		include "headerPage.php";
		include "../modules/loginSession.php";
		include "contactBody.php";
		include "footer.php";
?>