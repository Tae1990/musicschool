<?php
        include "../modules/session.php";
		include "../modules/database.php";
		include "../modules/sanitize.php";
		include "ownerHeader.php";
		include "../modules/loginSession.php";
		include "ownerContractPermissionBody.php";
		include "footer.php";
?>