<?php
		include "modules/session.php";
		include "modules/database.php";
		include "modules/sanitize.php";
		include "pages/headerIndex.php";
		include "modules/loginSessionIndex.php"; 
		include "pages/footerIndex.php";
?>

