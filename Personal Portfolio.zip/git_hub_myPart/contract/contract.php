<?php
include "../modules/session.php";
include "../modules/database.php";
include "../modules/sanitize.php";

include "new_navi.php";

//include "studentHeader.php";
include "contractBody.php";
//include "footer.php";
?>
